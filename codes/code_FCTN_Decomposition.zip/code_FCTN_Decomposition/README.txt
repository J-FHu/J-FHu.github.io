********************************************************************************************
    Fully-Connected Tensor Network Decomposition and Its Application 
                   to Higher-Order Tensor Completion
********************************************************************************************

         Copyright:  Yu-Bang Zheng, Ting-Zhu Huang,  Xi-Le Zhao, 
                                 Qibin Zhao, and Tai-Xiang Jiang

Please contact the author to obtain the password.
Email: zhengyubang@163.com 


 
 
 

